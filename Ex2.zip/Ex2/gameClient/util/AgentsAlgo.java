package gameClient.util;

import api.DW_GraphDS;
import gameClient.CL_Agent;
import gameClient.CL_Pokemon;

import java.util.ArrayList;

public class AgentsAlgo {
    private ArrayList<CL_Agent> agents;
    private ArrayList<CL_Pokemon> pokemons;
    private DW_GraphDS graph;
}
